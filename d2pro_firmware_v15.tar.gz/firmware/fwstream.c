#include <stdio.h>

void output_cmd(unsigned char *cmd) {
  int i;
  unsigned char chk = 0;
  for (i=0;i<11;i++)
    chk+=cmd[i];
  fwrite(cmd,11,1,stdout);
  putchar(chk);
}

void output_ins(unsigned int ins) {
  putchar(ins>>8);
  putchar(ins);
}

void output_delay() {
  output_ins(0x8000 | 32);
}

int main() {
  int c;
  int state = 0, nb=0, cmd_open=0;
  unsigned char buf[16];
  unsigned int len=0, addr=0, bleft=0;

  while ((c=getchar())>=0) {
    switch(state) {
      case 0:
        len = c << 24;
        state = 1;
        break;
      case 1:
        len |= c << 16;
        state = 2;
        break;
      case 2:
        len |= c << 8;
        state = 3;
        break;
      case 3:
        len |= c;
        state = 4;
        break;
      case 4:
        addr = c << 24;
        state = 5;
        break;
      case 5:
        addr |= c << 16;
        state = 6;
        break;
      case 6:
        addr |= c << 8;
        state = 7;
        break;
      case 7:
        addr |= c;
        if(addr&0xF0000000)
          state = 9;
        else if(len==0)
          state = 0;
        else {
          nb=0;
          state = 8;
          fprintf(stderr, "Address = %X, length = %d\n", addr, len);
        }
        break;
      case 8:
        if (bleft) {
          putchar(c);
          bleft--;
        } else {
          bleft = len;
          if (bleft > 16383)
            bleft = 16383;
          if (cmd_open) {
            putchar(0);
            output_delay();
            output_ins(1);
            putchar(0xFF);
          }
          buf[0]=0x30; buf[1]=0x00; buf[2]=addr>>16; buf[3]=addr>>8; buf[4]=addr;
          buf[5]=bleft>>8; buf[6]=bleft; buf[7]=0; buf[8]=0; buf[9]=0; buf[10]=0;
          output_ins(12);
          output_cmd(buf);
          output_delay();
          output_ins(1);
          putchar(0xFF);
          output_ins(bleft+1);
          putchar(c);
          bleft--;
          cmd_open = 1;
        }
        addr++;
        if(!--len) {
          state=0;
          if (cmd_open) {
            cmd_open=0;
            putchar(0);
            output_delay();
            output_ins(1);
            putchar(0xFF);
          }
        }
        nb++;
        break;
      case 9:
        output_ins(12);
        buf[0]=0x40;buf[1]=0x00;buf[2]=0x00;buf[3]=0x00;
        buf[4]=0x00;buf[5]=0x00;buf[6]=0x00;buf[7]=0x00;
        buf[8]=0x00;buf[9]=0x00;buf[10]=0x00;
        output_cmd(buf);

        output_delay();

        output_ins(1);
        putchar(0xFF);

        output_ins(0xFFFD);
        output_ins(0xFFFE);

        output_ins(12);
        buf[0]=0x20;buf[1]=0x2B;buf[2]=0xFC;buf[3]=0xDE;
        buf[4]=0x02;buf[5]=0xF3;buf[6]=0xFE;buf[7]=0xCA;
        buf[8]=0x60;buf[9]=0x00;buf[10]=0x00;
        output_cmd(buf);

        output_delay();

        output_ins(2);
        putchar(0xFF);
        putchar(0xFF);

        state = 0;
        break;
    }
  }
  output_ins(12);
  buf[0]=0x40;buf[1]=0x00;buf[2]=0x00;buf[3]=0x00;
  buf[4]=0x00;buf[5]=0x00;buf[6]=0x00;buf[7]=0x00;
  buf[8]=0x00;buf[9]=0x00;buf[10]=0x00;
  output_cmd(buf);
  output_delay();
  output_ins(1);
  putchar(0xFF);
  output_ins(0xFFFF);
  return 0;
}
