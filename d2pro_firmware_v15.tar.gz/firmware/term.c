#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termio.h>
#include <sys/select.h>
#include <signal.h>

int setbaud (int sfd, int baud) {
  struct termios tp;
  if (tcgetattr(sfd, &tp)<0) {
    fprintf (stderr, "setbaud() failed.\n");
    return 1;
  }
  tp.c_cflag=B0|baud|CS8|CLOCAL|CREAD;
  tp.c_oflag=0;
  tp.c_iflag=0;
  tp.c_lflag=0;
  cfsetspeed (&tp, baud);
  if (tcsetattr(sfd, TCSANOW, &tp)<0) {
    fprintf (stderr, "setbaud() failed.\n");
    return 1;
  }
  return 0;
}

static void sig(int sig) {
  
}

void terminal(int fd, int bps, int tr) {
  struct termios new_settings, stored_settings;
  unsigned char buf[8192];
  int r;
  int i;
  int is_newline = 1;
  fd_set rdfs;  
  struct timeval tv;
  signal(SIGINT, sig);
  FD_ZERO(&rdfs);

  printf ("--- entering console (%d bps) ---\n", bps);
  
  tcgetattr(0,&stored_settings);
  new_settings = stored_settings;
  
  /* Disable canonical mode, and set buffer size to 1 byte */
  new_settings.c_lflag &= (~ICANON);
  new_settings.c_lflag &= (~ECHO);
  new_settings.c_cc[VTIME] = 0;
  new_settings.c_cc[VMIN] = 1;
  
  tcsetattr(0,TCSANOW,&new_settings);

  while (1) {
    FD_SET(fd, &rdfs);
    FD_SET(STDIN_FILENO, &rdfs);
    tv.tv_sec = 0; tv.tv_usec = 100000;
    if (select(FD_SETSIZE, &rdfs, NULL, NULL, &tv)<0)
      break;
    if (FD_ISSET(fd, &rdfs)) {
      r = read(fd, buf, sizeof(buf));
      if (r<=0)
        break;
      for (i=0;i<r;i++)
        if (buf[i]<0x20 || buf[i]>0x7F) {
          buf[i]='?';
        } if (buf[i]=='\r') {
/*
          if (tr)
            buf[i]='\n';
*/
          is_newline = 1;
        } else
          is_newline = 0;
      write(STDOUT_FILENO, buf, r);
    }
    if (FD_ISSET(STDIN_FILENO, &rdfs)) {
      r = read(STDIN_FILENO, buf, sizeof(buf));
      if (r<=0)
        break;
      for (i=0;i<r;i++)
        if (buf[i]==0x1B) {
          write(fd,"\rAquaMarine",11);
          buf[i]='\r';
        } else if (buf[i]=='\n') {
          if (tr)
            buf[i]='\r';
          is_newline = 1;
        } else
          is_newline = 0;
      write(fd, buf, r);
    }
  }
  tcsetattr(0,TCSANOW,&stored_settings);
  if (!is_newline)
    printf ("\n");
  printf ("--- exiting console ---\n");
}

static int fd_ = -1;
static int bps_ = -1;
static int tr_ = -1;

int run_terminal() {
  terminal(fd_, bps_, tr_);
  close(fd_);
  return 0;
}

int init_terminal(char *fn, int bps, int tr) {
  int baud = -1;
  int fd;
  switch (bps) {
    case 300:
      baud = B300;
      break;
    case 1200:
      baud = B1200;
      break;
    case 2400:
      baud = B2400;
      break;
    case 4800:
      baud = B4800;
      break;
    case 9600:
      baud = B9600;
      break;
    case 19200:
      baud = B19200;
      break;
    case 38400:
      baud = B38400;
      break;
    case 57600:
      baud = B57600;
      break;
    case 115200:
      baud = B115200;
      break;
    case 500000:
      baud = B500000;
      break;
  }
  if (baud == -1) {
    fprintf (stderr, "ERROR: invalid bps value %d\n", bps);
    return 1;
  }
  fd = open(fn, O_RDWR);
  if (fd < 0) {
    fprintf (stderr, "ERROR: failed to open %s\n", fn);
    return 1;
  }
  if (setbaud(fd, baud)) {
    close(fd); 
    return 1;
  }
  fd_ = fd;
  bps_ = bps;
  tr_ = tr;
  return 0;
}
