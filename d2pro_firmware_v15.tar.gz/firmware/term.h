#ifndef _TERM_H
#define _TERM_H

int init_terminal(char *dev, int bps, int tr);
int run_terminal();

#endif
