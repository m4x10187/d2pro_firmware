#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// #define SIMPLE

unsigned short lfsr1=0;
unsigned short lfsr2=0;

void do_lfsr_enc(unsigned char *buf, int l) {
  int i;
  for (i=0;i<l;i++) {
#ifdef SIMPLE
    buf[i] ^= (lfsr1&0xFF) ^ (lfsr2&0xFF) ^ 0x69;
#else
    buf[i] ^= (lfsr1&0xFF) ^ (lfsr2&0xFF) ^ 0x69;
#endif
    lfsr1 = ((lfsr1&0xFFFF) >> 1) ^ (-(lfsr1&1)&0xD008);
    lfsr2 = ((lfsr2&0x7FFF) >> 1) ^ (-(lfsr2&1)&0x6000);
  }
}

int main(int argc, char *argv[]) {
  FILE *f;
  char buf[256];
  int gc_out = 0;
  unsigned char fw[10][1024*256];
  unsigned char out_img[1024*1024];
  unsigned int fw_addr[10];
  int fw_l[10];
  int total_used = 0;
  int fw_free = 0;
  int fw_total = 0;
  int i, a;
  unsigned int ver=0, rver=0;

  if (!strcmp(argv[1],"-g")) {
    gc_out=1;
    argv++;argc--;
  }
  
  srand(time(NULL));
    
  memset(out_img,0xFF,sizeof(out_img));

//  out_img[0] = 0x04;
//  out_img[0x1001]=0x00;
//  out_img[0x1005]=0x00;

  f=fopen("rescue.inc","r");
  fgets(buf,sizeof(buf),f);
  sscanf(buf,"%*s %*s $%X", &rver);
  fclose(f);
  f=fopen("config.inc","r");
  fgets(buf,sizeof(buf),f);
  sscanf(buf,"%*s %*s $%X", &ver);
  fclose(f);
  out_img[0xF0000]=rver>>24;
  out_img[0xF0001]=rver>>16;
  out_img[0xF0002]=rver>>8;
  out_img[0xF0003]=rver;
  out_img[0x80000]=ver>>24;
  out_img[0x80001]=ver>>16;
  out_img[0x80002]=ver>>8;
  out_img[0x80003]=ver;

//  out_img[0x0] = 0x02;
//  out_img[0x1005] = 0x00;

  for (i=0;i<10;i++) {
    if(!strcmp(argv[i+1],"null")) {
      fw_l[i] = 0;
    } else {
      f=fopen(argv[i+1],"rb");
      fw_l[i] = fread(fw[i],1,sizeof(fw[0]),f);
      fclose(f);
    }
  }

  fw_addr[0] = 0x81000;
  for (i=0;i<4;i++) {
    fw_addr[i+1] = fw_addr[i] + fw_l[i] + 4;
  }
  fw_addr[5] = 0xF0040;
  for (i=5;i<9;i++) {
    fw_addr[i+1] = fw_addr[i] + fw_l[i] + 4;
  }

#ifdef SIMPLE
  fw_addr[2] = 0x80004;
#endif
  
  for (i=0;i<10;i++) {
    if(fw_l[i]<=0)
      continue;
    if (i<5) {
      a = 0x80010 + ((i)<<2);
    } else {
      a = 0xF0010 + ((i-5)<<2);
    }
#ifndef SIMPLE
    out_img[a++] = fw_addr[i]>>16;
    out_img[a++] = fw_addr[i]>>8;
    out_img[a] = fw_addr[i];
#endif
    lfsr1 = rand();
    lfsr2 = rand();
    if(i==5) {
      lfsr1=0x95d9;lfsr2=0xbc0a;
    } else if (i==6) {
      lfsr1=0x90c6;lfsr2=0x6e6a;
    } else if (i==7) {
      lfsr1=0x81af;lfsr2=0xdc1c;
    } else if (i==8) {
      lfsr1=0xb50f;lfsr2=0x19f1;
    } else if (i==9) {
      lfsr1=0xab91;lfsr2=0x49fa;
    }
    out_img[fw_addr[i]+0] = lfsr1>>8;
    out_img[fw_addr[i]+1] = lfsr1;
    out_img[fw_addr[i]+2] = lfsr2>>8;
    out_img[fw_addr[i]+3] = lfsr2;
    lfsr1 |= 4;
    lfsr2 |= 16;
    do_lfsr_enc(fw[i],fw_l[i]);
    memcpy(out_img+fw_addr[i]+4,fw[i],fw_l[i]);
fprintf(stderr,"i=%d\n",i);
    if(i<5)
      fprintf(stderr,"D2%c: %X..%X (%d)\n", 'A'+i, fw_addr[i], fw_addr[i]+fw_l[i]-1, fw_l[i]);
    else
      fprintf(stderr,"D2%c: %X..%X (%d, rescue)\n", 'A'+i-5, fw_addr[i], fw_addr[i]+fw_l[i]-1, fw_l[i]);
    if(i<5)
      total_used += fw_l[i];
  }
  fw_total = 0xF0000-fw_addr[0];
  fw_free = fw_total-total_used;
  fprintf(stderr,"Firmware space used: %d/%d (%.1f%%)\n", total_used, fw_total, (total_used/(double)fw_total)*100.);
  
  f = fopen(argv[11],"w");
  if (gc_out)
    fwrite(out_img+0x80000,0xF0000-0x80000,1,f);
  else
    fwrite(out_img,sizeof(out_img),1,f);
  fclose(f);
  
  return 0;
}
