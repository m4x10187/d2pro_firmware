#include <stdio.h>

int main() {
  unsigned char buf[512];
  int i;
  while(fread(buf,sizeof(buf),1,stdin)==1) {
    for(i=0;i<sizeof(buf);i++)
      if(buf[i]!=0xFF)
        break;
    if(i==sizeof(buf)) {
      putchar(0);
    } else {
      putchar(1);
      fwrite(buf,sizeof(buf),1,stdout);
    }
  }
  return 0;
}
