#include <stdio.h>
#include <unistd.h>
#include <sys/io.h>
#include <string.h>
#include "term.h"

#define DBG

#define CLK_M 0x20
#define DATA_M 0x10
#define RESET_M 0x08

#define D 10

#define delay(v) {int i;for(i=0;i<v;i++)outb(0,0x80);}
#define clk(v) {outb((v)?inb(888)|CLK_M:inb(888)&~CLK_M,888);delay(D);}
#define data(v) {outb((v)?inb(888)|DATA_M:inb(888)&~DATA_M,888);delay(D);}
#define reset(v) {outb((v)?inb(888)|RESET_M:inb(888)&~RESET_M,888);}

#define data_i() (inb(889)&0x40)

void reset_drive() {
  reset(0);
  usleep(10000);
  reset(1);
}

unsigned char sp5_sr(unsigned char out) {
  int i, r=0;
  for (i=0;i<8;i++) {
    if (out & (1<<i)) {
      data(1);
    } else {
      data(0);
    }
    clk(0);
    if (data_i())
      r |= 1<<i;
    clk(1);
  }
  return r;
}

void sp5_chksum(unsigned char *cmd) {
  int i;
  cmd[11] = 0;
  for (i=0;i<11;i++)
    cmd[11] += cmd[i];
}

void sp5_cmd(unsigned char *cmd) {
  int i;
  sp5_chksum(cmd);
#ifdef DBG
  printf("> ");
#endif
  for (i=0;i<12;i++) {
#ifdef DBG
    printf("%02X ", cmd[i]);
#endif
    sp5_sr(cmd[i]);
  }
#ifdef DBG
  printf("\n");
#endif
}

void sp5_recv(unsigned char *buf, int n) {
  int i;
#ifdef DBG
  printf("< ");
#endif
  for (i=0;i<n;i++) {
    buf[i] = sp5_sr(0xFF);
#ifdef DBG
    printf("%02X ", buf[i]);
#endif
  }
#ifdef DBG
  printf("\n");
#endif
}

int sp5_act() {
  unsigned char cmd[12] = {0x20,0x2B,0xFC,0xDE,0x02,0xF3,0xFE,0xCA,0x60,0x00,0x00};
  unsigned char ans[2];
  sp5_cmd(cmd);
  sp5_recv(ans,2);
  if (ans[0]!=0x21 || ans[1]!=0x21)
    return 1;
  return 0;
}

int main(int argc, char *argv[]) {
  unsigned int ins;
  unsigned char buf[16];
  int i, ns=0, r;
  int enter_console = 1;
  FILE *f;
  
  argc--;argv++;
  while (argc > 1) {
    if(!strcmp(*argv,"-c")) {
      enter_console = 1;
    }
    argc--; argv++;
  }

  if (argc < 1) {
    return 1;
  }
  
  f = fopen(*argv,"rb");
  
  ioperm(888,3,1);
  ioperm(888+0x402,1,1);
  ioperm(0x80,1,1);

  outb(0x00,888+2);
  outb(0x00,888+0x402);
  outb(0xFF,888);
  
  clk(1);
  data(0);
  reset_drive();
  usleep(50000);

  if (enter_console) {
    init_terminal("/dev/ttyS0",115200,0);
  }
  
  if (sp5_act()) {
    fprintf(stderr,"failed to activate sp5 commands\n");
    return 1;
  }

  for (;;) {
    if(fread(buf,2,1,f)!=1)
      break;
    ins=buf[0]<<8|buf[1];
    if(ins&0x8000)
      continue;
    for(i=0;i<ins;i++) {
      r=sp5_sr(fgetc(f)); ns++;
      printf("%02X ", r);
    }
    printf("\n");
  }

  printf("done, sent %d bytes\n", ns);

  if (enter_console) {
    run_terminal();
  }

  return 0;
}

