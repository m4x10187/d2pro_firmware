#include <stdio.h>

int main(int argc, char *argv[]) {
  int n=0, nl=0, c;
  printf("const unsigned char %s[]={\n", argv[1]);
  while((c=getchar())>=0) {
    printf("0x%02X,",c);
    if(++nl>=16) {
      nl=0;
      printf("\n");
    }
    n++;
  }
  printf("};\n");
  printf("\nconst int %s_l=%d;\n", argv[1], n);
  return 0;
}
