#ifndef _MAIN_H
#define _MAIN_H

void my_sleep(unsigned int s);
void clear_console();
char *ver_str(unsigned int v);
void console_setxy(int x, int y);

extern unsigned int cur_fw;

#endif
