#ifndef _CONSOLE_H
#define _CONSOLE_H

void init_console();
void clear_console();
void console_setxy(int x, int y);
void console_setxy_r(int x, int y);
void cprintf(char *fmt, ...);
void ccprintf(char *fmt, ...);
void console_fgcolor(unsigned char c);

#endif
