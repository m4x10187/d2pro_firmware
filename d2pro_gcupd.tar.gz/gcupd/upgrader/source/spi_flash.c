#include <stdio.h>
#include <ogcsys.h>
#include <string.h>
#include <malloc.h>
#include "spi_flash.h"
#include "dvd.h"
#include "main.h"
#include "console.h"

#define FW_L (0xF0000-0x80000)

void fw_uncomp(unsigned char *dest, const unsigned char *src) {
  int imgp=0;
  int i;
  for(i=0;i<FW_L;i+=512) {
    if(src[imgp++]) {
      memcpy(dest+i,src+imgp,512);
      imgp+=512;
    } else {
      memset(dest+i,0xFF,512);
    }
  }
}

void unlock_fw_pages(u8 pages) {
  u8 pkt1[12] = {0x30,10, 0x26,0x23,0x00,0x06,0x25,0x26,0x23,0x01,0x01,(pages&7)<<2};
  u8 pkt2[12] = {0x30, 1, 0x25};
  dvd(pkt1);
  dvd(pkt2);
}

int spi_rdsr() {
  unsigned char r;
  u8 pkt1[12] = {0x30,6, 0x26,0x23,0x00,0x05,0x24,0x00};
  u8 pkt2[12] = {0x31,1};
  u8 pkt3[12] = {0x30,1, 0x25};
  dvd(pkt1);
  r = dvd(pkt2)[0];
  dvd(pkt3);
  return r;
}

int spi_read(unsigned char *buf, unsigned int addr, u8 n) {
  int i, nr;
  unsigned char *r;
  unsigned char pkt[12] = {0x30, 9, 0x26, 0x23, 0x03, 0x03, addr>>16, addr>>8, addr, 0x24, n-1, 0};
  unsigned char pkt2[12] = {0x31, n};
  unsigned char pkt3[12] = {0x30, 1, 0x25};
  dvd(pkt);
#if 0
  for (i=0;i<n;i+=4) {
    nr = n-i>4?4:n-i;
    pkt2[1]=nr;
    r = dvd(pkt2);
    memcpy(buf+i,r,nr);
  }
#else
  for (i=0;i<n;i++) {
    nr = 1;
    pkt2[1]=nr;
    r = dvd(pkt2);
    memcpy(buf+i,r,nr);
  }
#endif
  dvd(pkt3);

  return 0;
}

int spi_erase_page(unsigned int addr) {
  u8 pkt1[12] = {0x30,10, 0x26,0x23,0x00,0x06,0x25,0x26,0x23,0x03,0x20,addr>>16};
  u8 pkt2[12] = {0x30, 3, addr>>8,addr,0x25};
  dvd(pkt1);
  dvd(pkt2);
  while(spi_rdsr()&1)
    ;
  return 0;
}

void flash_pages(const unsigned char *img, unsigned int start, int len, int dots, int add) {
  int rlen=0,rdone=0;
  int perc, perc_m=0;
  int addr;
  int i;
  int skipped=1;
  for(i=start;i<start+len;i+=2)
    if(img[i]!=0xFF||img[i+1]!=0xFF)
      rlen+=2;
  for(i=start;i<start+len;i+=2) {
    if(img[i]!=0xFF||img[i+1]!=0xFF) {
      u8 add1, add2, add3;
      u8 byt1=img[i], byt2=img[i+1];
      addr=add+i; add1=addr>>16; add2=addr>>8; add3=addr;
      if (skipped) {
        u8 pkt1[12] = {0x30,10, 0x26,0x23,0x00,0x04,0x25,0x26,0x23,0x00,0x06,0x25};
        u8 pkt2[12] = {0x30,10, 0x26,0x23,0x05,0xAD,add1,add2,add3,byt1,byt2,0x25};
        dvd(pkt1);
        dvd(pkt2);
        skipped = 0;
      } else {
        u8 pkt1[12] = {0x30, 7, 0x26,0x23,0x02,0xAD,byt1,byt2,0x25};
        dvd(pkt1);
      }
      rdone+=2;
    } else {
      skipped = 1;
    }
    perc = (rdone/(float)rlen)*100;
    while(perc_m < perc || (rdone+2 >= rlen && perc_m < 100)) {
      perc_m++;
      if(dots && !(perc_m%(100/dots)))
        cprintf("*");fflush(stdout);
    }
  }
  {
    u8 pkt1[12] = {0x30, 5, 0x26,0x23,0x00,0x04,0x25};
    dvd(pkt1);
  }
}

int verify_pages(const unsigned char *img, unsigned int start, int len, int dots) {
  unsigned char vbuf[128];
  int rlen=0,rdone=0;
  int perc, perc_m=0;
  int i,j,n;
  for(i=start;i<start+len;i+=128) {
    n = start+len-i>128?128:start+len-i;
    for(j=0;j<n;j++)
      if (img[i+j]!=0xFF)
        break;
    if(j!=n)
      rlen+=n;
  }
  for(i=start;i<start+len;i+=128) {
    n = start+len-i>128?128:start+len-i;
    for(j=0;j<n;j++)
      if (img[i+j]!=0xFF)
        break;
    if(j!=n) {
      spi_read(vbuf,0x80000+i,n);
      if(memcmp(vbuf,img+i,n))
        return 1;
      rdone+=n;
    }
    perc = (rdone/(float)rlen)*100;
    while(perc_m < perc || (rdone+128 >= rlen && perc_m < 100)) {
      perc_m++;
      if(!(perc_m%(100/dots)))
        cprintf("*");fflush(stdout);
    }
  }
  return 0;
}

void do_fw_update(const unsigned char *img_) {
  int i,j;
  unsigned char *img = malloc(FW_L);
  unsigned char vbuf[16];

  clear_console();
  
  console_fgcolor(14);
  cprintf("\n");
  ccprintf("D2PRO FIRMWARE UPGRADER %s",ver_str(cur_fw));
  cprintf("\n\n");
  console_fgcolor(1);
  cprintf(" Firmware upgrade in progress.\n");
  cprintf(" Please do not power off your Wii.\n\n");
  
  fw_uncomp(img, img_);
  cprintf("  Erase ] ]\n");
  cprintf("  Flash ]                         ]\n");
  cprintf(" Verify ]                         ]\n");
  cprintf(" Enable ]                         ]\n");
  console_setxy(9,6);
  unlock_fw_pages(1);
  for(i=0;i<FW_L;i+=4096) {
    for(j=0;j<4096;j++)
      if(img[i+j]!=0xFF)
        break;
    if(j!=4096) {
      spi_erase_page(0x80000+i);
    }
    if (i==0) {
      unlock_fw_pages(7);
      spi_read(vbuf,0x80000,16);
      for(j=0;j<16;j++) {
        if(vbuf[j]!=0xFF) {
          cprintf("\n\n\n\n\n");
          cprintf(" Erase error!\n");
          cprintf("\n");
          goto error;
        }
      }
      unlock_fw_pages(1);
    }
  }
  cprintf("*");fflush(stdout);
  console_setxy(9,7);
  flash_pages(img,0x1000,FW_L-0x1000,25,0x80000);
  unlock_fw_pages(7);
  console_setxy(9,8);
  if (verify_pages(img,0x1000,FW_L-0x1000,25)) {
    cprintf("\n\n\n");
    cprintf(" Verify error!\n");
    cprintf("\n");
    cprintf(" The rescue firmware is now active.\n\n");
    goto error;
  }
  console_setxy(9,9);
  unlock_fw_pages(1);
  flash_pages(img,0,0x1000,25,0x80000);
  unlock_fw_pages(7);

  cprintf("\n\n");

  cprintf(" Done!\n\n");
  console_fgcolor(15);
  cprintf(" Please reboot your Wii now.\n");
  for(;;);  

error:
  cprintf(" Please disconnect and reconnect\n");
  cprintf(" your Wii power cable and try again.\n");
  for(;;);
}
