#ifndef _DVD_H
#define _DVD_H

void dvd_stop_motor();
unsigned int dvd_cmd(unsigned int cmd, unsigned int p1, unsigned int p2, int imm);
unsigned char *dvd(void *cmd_);
void dvd_reset();

#endif
