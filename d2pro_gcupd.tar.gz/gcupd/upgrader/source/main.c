#include <stdio.h>
#include <gccore.h>
#include <ogcsys.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dvd.h"
#include "spi_flash.h"
#include "main.h"
#include "console.h"

static vu32* const pireg = (u32*)0xCC003000;
 
unsigned int cur_fw = 0;
extern const unsigned char gcupd[];

void my_sleep(unsigned int s) {
  struct timespec tb;
  tb.tv_sec = s;
  tb.tv_nsec = 0;
  nanosleep(&tb);
}

void my_usleep(unsigned int s) {
  struct timespec tb;
  tb.tv_sec = 0;
  tb.tv_nsec = s*1000;
  nanosleep(&tb);
}

u32 get_d2pro_hw_version() {
  unsigned char *r;
  unsigned int ver=0;
  dvd("\x30\x01\x20\x00\x00\x00\x00\x00\x00\x00\x00\x00");
  r = dvd("\x31\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00");
  ver=r[0]<<8;
  r = dvd("\x31\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00");
  ver|=r[0];
  return ver;
}

unsigned int spi_read_id() {
  unsigned int ret;
  unsigned char *r;
  unsigned char pkt[12] = {0x30, 6, 0x26, 0x23, 0x00, 0x9F, 0x24, 0x02};
  unsigned char pkt2[12] = {0x31, 1};
  unsigned char pkt3[12] = {0x30, 1, 0x25};
  dvd(pkt);
  r = dvd(pkt2);
  ret = r[0]<<16;
  r = dvd(pkt2);
  ret |= r[0]<<8;
  r = dvd(pkt2);
  ret |= r[0];
  dvd(pkt3);
  return ret;
}

u32 get_d2pro_sw_version(unsigned int addr) {
  unsigned char buf[4]={0};
  spi_read(buf,addr,4);
  return buf[0]<<24|buf[1]<<16|buf[2]<<8|buf[3];
}

u8 get_drive_version() {
  unsigned char pkt[12] = {0x30,1, 0x28};
  unsigned char pkt2[12] = {0x31,1};
  dvd(pkt);
  return dvd(pkt2)[0];
}

void error_not_d2pro() {
  ccprintf("Sorry, no d2pro chip found!");
  for (;;)
    ;
}

void error_version() {
  cprintf(" This software is outdated or\n");
  cprintf(" the chip is corrupted.\n\n");
  cprintf(" Please check for updates from\n");
  cprintf(" http://d2pro.com/\n");
  for (;;)
    ;
}

char *ver_str(unsigned int v) {
  static char ans_[2][32];
  static int na=0;
  static char *ans;
  ans=ans_[na++];
  if(na>1)
    na=0;
  if (v==0 || (v&0x7FFF7FFF) > 0x00200000)
    return "V???";
  sprintf(ans,"V%d.%d%s%s", (v>>16)&0x7FFF, v&0x7FFF, v&0x8000?"":"", v&0x80000000?"B":"");
  return ans;
}

/* -1: chip fw is older
    0: current
    1: chip fw is newer */
int ver_comp(unsigned int v) {
  if ((v&0x7FFF7FFF) > (cur_fw&0x7FFF7FFF)) {
    return 1;
  }
  if ((v&0x7FFF7FFF) < (cur_fw&0x7FFF7FFF)) {
    return -1;
  }
  if (!(v&0x80000000) && (cur_fw&0x80000000))
    return 1;
  if ((v&0x80000000) && !(cur_fw&0x80000000))
    return -1;
  return 0;
}

int is_reset() {
  return !(pireg[0]&0x00010000);
}

void fw_update(int down) {
  int ndot=0, i;
  cprintf("\nFirmware %sgrade (%s) is\n", down?"down":"up", ver_str(cur_fw));
  cprintf("required to use this utility disc.\n");
  cprintf("\n");
  cprintf("Do NOT remove the utility disc.\n\n");
  console_fgcolor(15);
  cprintf("\n Hold down reset button for 3 seconds\n");
  cprintf(" to proceed.\n");
  cprintf("\n");
  console_fgcolor(1);
  cprintf("     ]                         ]\b");

  do {
    if(is_reset())
      ndot++;
    else if(ndot>0)
      ndot--;
    for(i=0;i<25;i++)
      cprintf("\b");
    for(i=0;i<ndot;i++)
      cprintf("*");
    for(i=ndot;i<25;i++)
      cprintf(" ");
    usleep(120000);
  } while(ndot<25);

  usleep(500000);
  
  do_fw_update(gcupd);
}

int first_run=1;

int check_chip() {
  unsigned char addr[12];
  unsigned char caddr[4]={0xFF,0xFF,0xFF,0xFF};
  const char *drv_ver_s[] = {"D2A", "D2B", "D2C", "D2C2", "D2E"};
  int need_update=0;
  int r;
  unsigned int hw_ver;
  unsigned int sw_ver=0xFFFFFFFF;
  unsigned int rs_ver;
  unsigned int spi_id;
  unsigned char drv_ver;

  dvd("\xe3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00");   /* stop motor */

  clear_console();

  cur_fw = gcupd[1]<<24|gcupd[2]<<16|gcupd[3]<<8|gcupd[4];

  if (first_run) {
//    cur_fw = 0x00010000;
    first_run=0;
  }
  console_setxy(0,1);
  console_fgcolor(14);
  ccprintf("*** D2PRO UTILITY DISC %s ***", ver_str(cur_fw));
  cprintf("\n\n");
  hw_ver = get_d2pro_hw_version();
  if (hw_ver==0)
    error_not_d2pro();

  drv_ver = get_drive_version();
  if (drv_ver>4)
    error_not_d2pro();

  spi_id = spi_read_id();
  if ((hw_ver!=0x0101&&hw_ver!=0x0102&&hw_ver!=0x0200&&hw_ver!=0x0201&&hw_ver!=0x0202&&hw_ver!=0x0203&&hw_ver!=0x0204) || spi_id!=0xBF258E)
    error_version();
  spi_read(addr+0,0x80010,3);
  spi_read(addr+3,0x80014,3);
  spi_read(addr+6,0x80018,3);
  spi_read(addr+9,0x8001C,3);
  if (memcmp(addr+0,caddr,3) &&
      memcmp(addr+3,caddr,3) &&
      memcmp(addr+6,caddr,3) &&
      memcmp(addr+9,caddr,3))
    sw_ver = get_d2pro_sw_version(0x80000);
  rs_ver = get_d2pro_sw_version(0xF0000);

  ccprintf("1M %s SYSTEM    HW V%d.%d    FW %s", drv_ver_s[drv_ver],(hw_ver>>8)&0xFF,hw_ver&0xFF,ver_str(sw_ver));
  cprintf("\n\n");

  console_fgcolor(1);

  if (sw_ver==0 || sw_ver==0xFFFFFFFF) {
    cprintf("\nFirmware is missing.\n");
    need_update = 1;
  } else {
    r = ver_comp(sw_ver);
    if (r==-1) {
      cprintf("\nNew firmware version available.\n");
      need_update = 1;
    } else if (r==1) {
      cprintf("\nThe firmware is newer than\n");
      cprintf("this utility disc.\n");
      need_update = 2;
    }
  }

  return need_update;
}

/*

bar

foo

READY.
   
   
  Region patcher          ON OFF
  Audio fix               ON OFF
  Backup read speed       6X 3X
  DL backup read speed    6X 3X
  Original read speed     6X 3X
  Original DL read speed  6X 3X
  Save settings
  Force upgrade firmware
   
   
 Operate this menu with the reset button.
 Short press = change selection
  Long press = enter
*/

void clear_mainarea() {
  int x,y;
  console_setxy(0,7);
  for(y=0;y<17;y++)
    for(x=0;x<38;x++)
      cprintf(" ");
}

void save_settings(unsigned char *s) {
  unsigned char buf[0x2000];
  clear_mainarea();
  memset(buf,0xFF,0x2000);
  memcpy(buf+0x1001,s,6);
  console_setxy(0,12);
  unlock_fw_pages(4);
  spi_erase_page(0x1000);
  flash_pages(buf,0x1000,0x1000,0,0);
  unlock_fw_pages(7);
  console_fgcolor(1);
  ccprintf("Settings saved.");
  cprintf("\n\n");
  console_fgcolor(15);
  ccprintf("Please reboot your Wii now.\n");
  for(;;);
}

void setupmenu() {
  unsigned char settings[8]={0};

  spi_read(settings,0x1001,6);
  
  char *setting_str[8] = {
    "Region patcher        ",
    "Audio fix             ",
    "Original read speed   ",
    "Original DL read speed",
    "Backup read speed     ",
    "DL backup read speed  ",
    "Save settings         ", 
    "Force firmware upgrade"
  };
  char *opts[8][2] = {
    {"ON","OFF"},
    {"ON","OFF"},
    {"6X","3X"},
    {"6X","3X"},
    {"6X","3X"},
    {"6X","3X"},
    {"",""},
    {"",""}
  };
  int i,sm=0,mode=0,n_down=0,n_up=0,press=0;
  clear_mainarea();
  for(;;) {
    console_setxy(0,8);
    for (i=0;i<8;i++) {
      console_fgcolor(15);
      cprintf("  %c ", (sm==i&&mode==0)?'*':' ');
      console_fgcolor(14);
      cprintf("%s  ", setting_str[i]);
      console_fgcolor(settings[i]?1:0);
      cprintf("%s ", opts[i][0]);
      console_fgcolor(settings[i]?0:1);
      cprintf("%s ", opts[i][1]);
      console_fgcolor(1);
      cprintf("%c\n", (sm==i&&mode==1)?'*':' ');
    }
    cprintf("\n\n");
    console_fgcolor(15);
    cprintf("  Operate this menu with\n");
    cprintf("  the reset button.\n");
    cprintf("\n");
    cprintf("  Short press = change selection\n");
    cprintf("   Long press = enter\n");
    n_down=n_up=0;
    for(;;) {
      if(is_reset()) {
        n_up=0;
      } else {
        n_up++;
      }
      if(n_up>25)
        break;
      my_usleep(1000);
    }
    n_down=n_up=0;
    for(;;) {
      if(is_reset()) {
        n_down++;
        n_up=0;
      } else {
        if(n_up<15) {
          n_up++;
        } else {
          n_down=0;
        }
      }
      if((n_down>=5&&n_down<800) && n_up>10) {
        press=0;
        break;
      }
      if((sm<6&&n_down>=800)||n_down>=2000) {
        press=1;
        break;
      }
      my_usleep(1000);
    }
    if(!press) {
      if(mode==0) {
        sm++;
        if(sm>7)
          sm=0;
      } else {
        if(settings[sm])
          settings[sm]=0;
        else
          settings[sm]=0xFF;
      }
    } else {
      if(sm<6) {
        mode=!mode;
      } else {
        if(sm==6) {
          save_settings(settings);
        }
        if(sm==7) {
          do_fw_update(gcupd);
        }
      }
    }
  }
}

void mainloop() {
  int buttons;
  int nu;
  
  for (;;) {
    nu = check_chip();
    if(!nu)
      break;
    fw_update(nu==2);
  }
  
  console_fgcolor(14);
  cprintf("READY.\n\n");

  setupmenu();
}
 
int main () {
  init_console();

  mainloop();

  return 0;
}
