#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ogcsys.h>

#define DVD_BRK                                                 (1<<0)
#define DVD_DE_MSK                                              (1<<1)
#define DVD_DE_INT                                              (1<<2)
#define DVD_TC_MSK                                              (1<<3)
#define DVD_TC_INT                                              (1<<4)
#define DVD_BRK_MSK                                             (1<<5)
#define DVD_BRK_INT                                             (1<<6)

#define DVD_CVR_INT                                             (1<<2)
#define DVD_CVR_MSK                                             (1<<1)
#define DVD_CVR_STATE                                   (1<<0)

#define DVD_DI_MODE                                             (1<<2)
#define DVD_DI_DMA                                              (1<<1)
#define DVD_DI_START                                    (1<<0)

#define DVD_DISKIDSIZE                                  0x20
#define DVD_DRVINFSIZE                                  0x20
#define DVD_MAXCOMMANDS                                 0x12

static vu32* const direg = (u32*)0xCC006000;
static vu32* const pireg = (u32*)0xCC003000;

void dvd_reset() {
  u32 val;
  val = pireg[9];
  pireg[9] = ((val&~4)|1);
  usleep(12);
  val |= 1 | 4;
  pireg[9] = val;
}

unsigned int dvd_cmd(unsigned int cmd, unsigned int p1, unsigned int p2, int imm) {
  direg[2] = cmd;
  direg[3] = p1;
  direg[4] = p2;
  direg[6] = 0;
  direg[8] = 0;
  if (imm)
    direg[7] = DVD_DI_START;
  else
    direg[7] = DVD_DI_START | DVD_DI_DMA;
  while(direg[7]&DVD_DI_START)
    ;
  return direg[8];
}

unsigned char *dvd(void *cmd_) {
  unsigned int ret; 
  unsigned char *cmd = cmd_;
  static unsigned char ans[4];
  ret = dvd_cmd(cmd[0]<<24|cmd[1]<<16|cmd[2]<<8|cmd[3],
                cmd[4]<<24|cmd[5]<<16|cmd[6]<<8|cmd[7],
                cmd[8]<<24|cmd[9]<<16|cmd[10]<<8|cmd[11],
                1);
  ans[0]=ret>>24;
  ans[1]=ret>>16;
  ans[2]=ret>>8;
  ans[3]=ret;
  return ans;
}

