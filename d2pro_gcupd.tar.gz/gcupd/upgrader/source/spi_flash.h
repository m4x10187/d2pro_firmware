#ifndef _SPI_FLASH_H
#define _SPI_FLASH_H

void do_fw_update(const unsigned char *img);
int spi_read(unsigned char *buf, unsigned int addr, u8 n);
void unlock_fw_pages(u8 pages);
int spi_erase_page(unsigned int addr);
void flash_pages(const unsigned char *img, unsigned int start, int len, int dots, int add);

#endif
