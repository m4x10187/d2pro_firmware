#include <stdio.h>
#include <gccore.h>
#include <ogcsys.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define W fb_w
#define H fb_h

extern unsigned char c64_chargen[];

int fb_w;
int fb_w2;
int fb_h;

u32 *xfb = NULL;
GXRModeObj *vmode = NULL;

typedef struct {
  int x, y;
  int bd_w, bd_h;
  int bd_w2;
  int nx, ny;
} t_fb;

t_fb fb_d;

unsigned char pal[16][3] = {
  {0x00,0x00,0x00},
  {0xFF,0xFF,0xFF},
  {0x68,0x37,0x2B},
  {0x70,0xA4,0xB2},
  {0x6F,0x3D,0x86},
  {0x58,0x8D,0x43},
  {0x35,0x28,0x79},
  {0xB8,0xC7,0x6F},
  {0x6F,0x4F,0x25},
  {0x43,0x39,0x00},
  {0x9A,0x67,0x59},
  {0x44,0x44,0x44},
  {0x6C,0x6C,0x6C},
  {0x9A,0xD2,0x84},
  {0x6C,0x5E,0xB5},
  {0x95,0x95,0x95}
};

unsigned int xpal[16];

unsigned int fgcolor;
unsigned int bgcolor;               
unsigned int bdcolor;

static void create_xpal() {
  int i;
  for(i=0;i<16;i++) {
    unsigned char r, g, b, cb, cr, y;
    r=pal[i][0];
    g=pal[i][1];
    b=pal[i][2];
    y = (77/256.)*r+(150/256.)*g+(29/256.)*b;
    cb = -(44/256.)*r - (87/256.)*g + (131/256.)*b + 128;
    cr = (131/256.)*r - (110/256.)*g - (21/256.)*b + 128;
    xpal[i] = y<<24 | cb<<16 | y<<8 | cr;
  }
}

void setcolor(unsigned int *dst, int n) {
  *dst = xpal[n];
}

void console_fgcolor(unsigned char c) {
  setcolor(&fgcolor,c);
}

void fb_rendchar(int x2, int y, unsigned char c) {
  int i, j;
  int c1;
  int p=8*(c+256);
  for(j=0;j<8;j++) {
    for(i=0;i<8;i++) {
      c1 = (c64_chargen[p]&128>>(i))?fgcolor:bgcolor;
      xfb[x2+i+fb_d.bd_w2+fb_w2*(fb_d.bd_h+y+j*2)] = c1;
      xfb[x2+i+fb_d.bd_w2+fb_w2*(fb_d.bd_h+y+j*2+1)] = c1;
    }
    p++;
  }
}

void fb_putchar(char c) {
  unsigned char pc = c;
  if(pc>='a'&&pc<='z') {
    pc-='a';
    pc++;
  } else if(pc=='\n') {
    fb_d.x=0; fb_d.y++;
    if(fb_d.y>=fb_d.ny) {
      goto scroll;
    }
    return;
  } else if(pc=='\r') {
    fb_d.x=0;
    return;
  } else if(pc=='\b') {
    fb_d.x--;
    return;
  }
  fb_rendchar(fb_d.x*8, fb_d.y*16, (unsigned char)(pc));
  if(++fb_d.x>=fb_d.nx) {
    fb_d.x=0;
    if(++fb_d.y>=fb_d.ny) {
      goto scroll;
    }
  }
  return;
scroll:
  memmove(((unsigned char*)xfb)+fb_w2*fb_d.bd_h*4, ((unsigned char*)xfb)+fb_w2*(fb_d.bd_h+16)*4, fb_w2*16*(fb_d.ny-1)*4);
  fb_d.y--;
}

void fb_puts(char *s) {
  while(*s)
    fb_putchar(*s++);
}

void fb_clear() {
  int x,y;
  for(y=0;y<fb_h;y++) {
    for(x=0;x<fb_w2;x++) {
      if(x<fb_d.bd_w2 || x>=fb_d.bd_w2+fb_d.nx*8 ||
         y<fb_d.bd_h || y>=fb_d.bd_h+fb_d.ny*16)
        xfb[fb_w2*y+x] = bdcolor;
      else
        xfb[fb_w2*y+x] = bgcolor;
    }
  }
}

void init_console() {
  VIDEO_Init();
  switch (VIDEO_GetCurrentTvMode()) {
    case VI_NTSC:
      vmode = &TVNtsc480IntDf;
      break;
    case VI_PAL:
      vmode = &TVPal528IntDf;
      break;
    case VI_MPAL:
      vmode = &TVMpal480IntDf;
      break;
    default:
      vmode = &TVNtsc480IntDf;
      break;
  }
  VIDEO_Configure(vmode);
  fb_w = vmode->fbWidth;
  fb_w2 = vmode->fbWidth/2;
  fb_h = vmode->xfbHeight;
  xfb = (u32*)MEM_K0_TO_K1(SYS_AllocateFramebuffer(vmode));
  VIDEO_ClearFrameBuffer(vmode, xfb, COLOR_BLACK);
  VIDEO_SetNextFramebuffer(xfb);
  VIDEO_SetBlack(0);
  VIDEO_Flush();
  memset(&fb_d,0,sizeof(fb_d));
  fb_d.nx = 38;
  fb_d.ny = 25;
  fb_d.bd_w = (fb_w-16*fb_d.nx)/2;
  fb_d.bd_h = (fb_h-16*fb_d.ny)/2;
  fb_d.bd_w2=fb_d.bd_w/2;
  create_xpal();
  setcolor(&bdcolor,14);
  setcolor(&bgcolor,6);
  setcolor(&fgcolor,14);
  fb_clear();
}

void clear_console() {
  fb_clear();
  fb_d.x=0; fb_d.y=0;
}

void console_setxy(int x, int y) {
  fb_d.x=x; fb_d.y=y;
}

void console_setxy_r(int x, int y) {
  fb_d.x+=x; fb_d.y+=y;
}

void cprintf(char *str, ...) {
  char buf[1024];
  va_list arg_ptr;
  va_start (arg_ptr, str);
  vsprintf (buf, str, arg_ptr);
  va_end (arg_ptr);
  fb_puts(buf);
}

void ccprintf(char *str, ...) {
  char buf[1024];
  va_list arg_ptr;
  va_start (arg_ptr, str);
  vsprintf (buf, str, arg_ptr);
  va_end (arg_ptr);
  fb_d.x=fb_d.nx/2-strlen(buf)/2;
  fb_puts(buf);
}
