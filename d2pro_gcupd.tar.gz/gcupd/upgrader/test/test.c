#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GLUT/glut.h>

#define W 640
#define H 480

extern unsigned char c64_chargen[];

GLuint fb_tex;
unsigned char *fb;

typedef struct {
  int x, y;
  int bd_w, bd_h;
  int nx, ny;
} t_fb;

t_fb fb_d;

unsigned char pal[16][3] = {
  {0x00,0x00,0x00},
  {0xFF,0xFF,0xFF},
  {0x68,0x37,0x2B},
  {0x70,0xA4,0xB2},
  {0x6F,0x3D,0x86},
  {0x58,0x8D,0x43},
  {0x35,0x28,0x79},
  {0xB8,0xC7,0x6F},
  {0x6F,0x4F,0x25},
  {0x43,0x39,0x00},
  {0x9A,0x67,0x59},
  {0x44,0x44,0x44},
  {0x6C,0x6C,0x6C},
  {0x9A,0xD2,0x84},
  {0x6C,0x5E,0xB5},
  {0x95,0x95,0x95}
};

unsigned char fgcolor[3] = {0};
unsigned char bgcolor[3] = {0};
unsigned char bdcolor[3] = {0};

void setcolor(unsigned char *dst, int n) {
  memcpy(dst,pal[n],3);
}

void fb_rendchar(int x, int y, unsigned char c) {
  int i, j;
  int p=8*(c+256);
  for(j=0;j<8;j++) {
    for(i=0;i<8;i++) {
      if(c64_chargen[p]&128>>i)
        memcpy(&fb[((fb_d.bd_h+y+j)*W+x+i+fb_d.bd_w)*3],fgcolor,3);
      else
        memcpy(&fb[((fb_d.bd_h+y+j)*W+x+i+fb_d.bd_w)*3],bgcolor,3);
    }
    p++;
  }
}

void fb_putchar(char c) {
  unsigned char pc = c;
  if(pc>='a'&&pc<='z') {
    pc-='a';
    pc++;
  } else if(pc=='\n') {
    fb_d.x=0; fb_d.y++;
    if(fb_d.y>=fb_d.ny) {
      goto scroll;
    }
    return;
  } else if(pc=='\r') {
    fb_d.x=0;
    return;
  } else if(pc=='\b') {
    fb_d.x--;
    return;
  }
  fb_rendchar(fb_d.x*8, fb_d.y*8, (unsigned char)(pc));
  if(++fb_d.x>=fb_d.nx) {
    fb_d.x=0;
    if(++fb_d.y>=fb_d.ny) {
      goto scroll;
    }
  }
  return;
scroll:
  memmove(fb+W*fb_d.bd_h*3, fb+W*(fb_d.bd_h+8)*3, W*8*(fb_d.ny-1)*3);
  fb_d.y--;
}

void fb_clear() {
  int x,y;
  for(y=0;y<H;y++) {
    for(x=0;x<W;x++) {
      if(x<fb_d.bd_w || x>=fb_d.bd_w+fb_d.nx*8 ||
         y<fb_d.bd_h || y>=fb_d.bd_h+fb_d.ny*8)
        memcpy(fb+(W*y+x)*3,bdcolor,3);
      else
        memcpy(fb+(W*y+x)*3,bgcolor,3);
    }
  }
}

void fb_puts(char *s) {
  while(*s)
    fb_putchar(*s++);
}

void idle() {
  static int cnt=0;
  printf("idle %d\n",cnt++);
  glutPostRedisplay();
}

void display() {
  static int c=0;
  gluBuild2DMipmaps(GL_TEXTURE_2D,3,W,H,GL_RGB,GL_UNSIGNED_BYTE,fb);
// glTexImage2D(GL_TEXTURE_2D,100,3,W,H,10,GL_RGB,GL_UNSIGNED_BYTE,fb);

 fb_putchar(c++);
  glClear(GL_COLOR_BUFFER_BIT);
  glEnable(GL_TEXTURE_2D);
//  glShadeModel(GL_SMOOTH);
  glBegin(GL_POLYGON);
  glColor3f(1,1,1);
  glTexCoord2d(0,1);
  glVertex2d(-1,-1);
  glTexCoord2d(1,1);
  glVertex2d(1,-1);
  glTexCoord2d(1,0);
  glVertex2d(1,1);
  glTexCoord2d(0,0);
  glVertex2d(-1,1);
  glEnd();
  glDisable(GL_TEXTURE_2D);
  glShadeModel(GL_FLAT);
  glutSwapBuffers();
}

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  glutInitWindowSize(640,480);
  
  glutInitDisplayMode(GLUT_RGB);
  glutCreateWindow("test");

  glutDisplayFunc(display);

  glGenTextures(1,&fb_tex);
  glBindTexture(GL_TEXTURE_2D,fb_tex);
  glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE);

  fb = malloc(W*H*3);

  memset(fb,0,sizeof(fb));
  memset(&fb_d,0,sizeof(fb_d));

  fb_d.bd_w=6*8;
  fb_d.bd_h=6*8;
  fb_d.nx = (W-fb_d.bd_w*2)/8;
  fb_d.ny = (H-fb_d.bd_h*2)/8;
  setcolor(bdcolor,14);
  setcolor(bgcolor,6);
  setcolor(fgcolor,14);

  fb_clear();

  glutIdleFunc(idle);

  glutMainLoop();
  
  return 0;
}
